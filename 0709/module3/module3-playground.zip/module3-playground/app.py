"""MockIRS - a fake Interactive Response System (Zuvio/FlipClass-style).

A local teaching playground: students drive an AI agent to retrieve data files
or scrape tables across a 5-level difficulty ladder. UI and shown/retrieved
data are bilingual (zh-TW default / en) and the theme is switchable
(dark default / light). Route names and data keys stay English so scraping
targets are stable.

Run:  python app.py   ->  opens http://127.0.0.1:5000 in the default browser
"""

import os
import secrets
import threading
import webbrowser
from functools import wraps

from flask import (
    Flask,
    Response,
    abort,
    redirect,
    render_template,
    request,
    session,
    url_for,
)

from mockirs import data, exports, i18n

app = Flask(__name__)
app.secret_key = "mock-irs-not-secret"  # intentionally insecure: local playground only

DEFAULT_THEME = "dark"
THEMES = ("dark", "light")


# ---- preferences (language + theme) -------------------------------------

def get_lang():
    return data.norm_lang(request.cookies.get("lang", i18n.DEFAULT_LANG))


def get_theme():
    th = request.cookies.get("theme", DEFAULT_THEME)
    return th if th in THEMES else DEFAULT_THEME


@app.route("/prefs/lang/<lang>")
def set_lang(lang):
    resp = redirect(request.referrer or url_for("home"))
    resp.set_cookie("lang", data.norm_lang(lang), max_age=31536000, samesite="Lax")
    return resp


@app.route("/prefs/theme/<theme>")
def set_theme(theme):
    resp = redirect(request.referrer or url_for("home"))
    resp.set_cookie(
        "theme", theme if theme in THEMES else DEFAULT_THEME,
        max_age=31536000, samesite="Lax",
    )
    return resp


# ---- auth helpers --------------------------------------------------------

def current_user():
    uid = session.get("uid")
    return data.find_account(uid) if uid else None


def current_user_view():
    return data.account_view(current_user(), get_lang())


def require_login(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not current_user():
            return redirect(url_for("login", next=request.path))
        return view(*args, **kwargs)

    return wrapped


def scope_id():
    """Returns None for a teacher (sees everyone) or the student's own id."""
    u = current_user()
    if u and u.get("role") == "teacher":
        return None
    return u["student_id"] if u else None


@app.context_processor
def inject_globals():
    lang = get_lang()
    return {
        "user": current_user_view(),
        "lang": lang,
        "theme": get_theme(),
        "t": lambda key: i18n.t(key, lang),
    }


# ---- auth routes ---------------------------------------------------------

@app.route("/")
@require_login
def home():
    # Instructor dashboard landing: launching the app always requires login.
    return render_template("home.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    lang = get_lang()
    if request.method == "POST":
        token = request.form.get("csrf_token", "")
        if not token or token != session.get("csrf_token"):
            # Recoverable: mint a fresh token so the next submit can succeed.
            session["csrf_token"] = secrets.token_hex(16)
            return render_template("login.html", error=i18n.t("err_csrf", lang),
                                   next=request.form.get("next", "")), 400
        sid = request.form.get("student_id", "").strip()
        pw = request.form.get("password", "").strip()
        if data.check_password(sid, pw):
            acct = data.find_account(sid)
            session["uid"] = sid
            session["role"] = acct.get("role", "student")
            session.pop("csrf_token", None)
            nxt = request.args.get("next") or request.form.get("next")
            return redirect(nxt or url_for("dashboard"))
        return render_template("login.html", error=i18n.t("err_credentials", lang),
                               next=request.form.get("next", "")), 401

    # GET: reuse the session's CSRF token if it already has one, so refreshing,
    # the back button, or a tab left open across a restart still match. Only
    # mint a new token when the session lacks one.
    if not session.get("csrf_token"):
        session["csrf_token"] = secrets.token_hex(16)
    return render_template("login.html", error=None, next=request.args.get("next", ""))


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("home"))


@app.route("/auto-login/<student_id>")
def auto_login(student_id):
    """Bypass ramp for beginners: /auto-login/<id>?token=DEMO."""
    lang = get_lang()
    if request.args.get("token") != data.DEMO_TOKEN:
        abort(403, i18n.t("err_token", lang))
    acct = data.find_account(student_id)
    if not acct:
        abort(404, i18n.t("err_no_account", lang))
    session["uid"] = student_id
    session["role"] = acct.get("role", "student")
    return redirect(url_for("dashboard"))


@app.route("/dashboard")
@require_login
def dashboard():
    u = current_user()
    tmpl = "teacher_home.html" if u.get("role") == "teacher" else "student_home.html"
    return render_template(tmpl)


# ---- Level 1: public roster directory at /public (identity only) ---------
# Public data is intentionally limited to roster id / name / class across
# several classes. The formative grading scores live behind a teacher login
# (Exercise 3 + export). Add ?course=<course_id> to any download to filter.

def _roster_filename(course_id, ext):
    return "{}.{}".format(course_id or "roster", ext)


def _select_course(lang):
    """Resolve the active course from ?course=, defaulting to the first."""
    courses = data.course_list(lang)
    cid = request.args.get("course") or courses[0]["course_id"]
    selected = next((c for c in courses if c["course_id"] == cid), courses[0])
    return courses, selected


@app.route("/public/buttons/")
def public_buttons():
    # Exercise 1: same public roster, but the course is chosen with buttons
    # (one link per course) instead of a pop-menu / dropdown.
    lang = get_lang()
    courses, selected = _select_course(lang)
    rows = data.roster_rows(selected["course_id"], lang)
    return render_template("public_buttons.html", courses=courses, selected=selected, rows=rows)


@app.route("/public/")
def public_index():
    lang = get_lang()
    courses, selected = _select_course(lang)
    rows = data.roster_rows(selected["course_id"], lang)
    return render_template("public.html", courses=courses, selected=selected, rows=rows)


@app.route("/public/roster.csv")
def public_csv():
    cid = request.args.get("course") or None
    return Response(
        exports.roster_csv(lang=get_lang(), course_id=cid),
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment; filename=" + _roster_filename(cid, "csv")},
    )


@app.route("/public/roster.json")
def public_json():
    cid = request.args.get("course") or None
    return Response(exports.roster_json(lang=get_lang(), course_id=cid),
                    mimetype="application/json")


@app.route("/public/roster.xlsx")
def public_xlsx():
    cid = request.args.get("course") or None
    blob = exports.roster_xlsx(lang=get_lang(), course_id=cid)
    if blob is None:
        abort(404, "openpyxl not installed; use CSV or JSON instead.")
    return Response(
        blob,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment; filename=" + _roster_filename(cid, "xlsx")},
    )


# ---- Level 2: login wall -> dashboard with tables ------------------------

@app.route("/l2/dashboard")
@require_login
def l2_dashboard():
    lang = get_lang()
    sid = scope_id()

    # Course pop-menu: empty value ("") means all enrolled courses.
    course_list = data.course_list(lang)
    cid = request.args.get("course") or ""
    selected_course = next((c for c in course_list if c["course_id"] == cid), None)
    course_id = selected_course["course_id"] if selected_course else None

    # Quiz pop-menu: when a quiz is chosen, blend its (normalized) score into
    # the overall grade; empty value ("") means the overall grade is just the
    # formative average.
    quiz_options = [
        {"quiz_id": q["quiz_id"], "title": data.quiz_title(q, lang)}
        for q in data.quizzes()
    ]
    qzid = request.args.get("quiz") or ""
    selected_quiz = next((q for q in quiz_options if q["quiz_id"] == qzid), None)

    grades = data.gradebook_rows(sid, course_id=course_id, lang=lang)
    if selected_quiz:
        qpct = {
            r["student_id"]: r["percent"]
            for r in data.quiz_score_rows(
                selected_quiz["quiz_id"], sid, course_id=course_id, lang=lang)
        }
        for r in grades:
            r["quiz_pct"] = qpct.get(r["student_id"], 0)
            # Overall = mean of the formative average and the quiz percentage.
            r["overall"] = round((r["average"] + r["quiz_pct"]) / 2, 1)
    else:
        for r in grades:
            r["overall"] = r["average"]

    # Without a selection, show every quiz for comparison. Once a quiz is
    # selected for the overall grade, keep the page focused on that one quiz.
    displayed_quiz_ids = [selected_quiz["quiz_id"]] if selected_quiz else [
        q["quiz_id"] for q in data.quizzes()
    ]
    quizzes = [
        {
            "title": data.quiz_title(data.quiz(quiz_id), lang),
            "quiz_id": quiz_id,
            "rows": data.quiz_score_rows(
                quiz_id, sid, course_id=course_id, lang=lang),
        }
        for quiz_id in displayed_quiz_ids
    ]
    return render_template(
        "l2_dashboard.html",
        grades=grades,
        cols=data.ASSESSMENT_KEYS,
        labels=data.assessment_labels(lang),
        quizzes=quizzes,
        courses=course_list,
        selected_course=selected_course,
        quiz_options=quiz_options,
        selected_quiz=selected_quiz,
    )


# ---- Level 3: nested navigation + typed search ---------------------------

@app.route("/l3/courses")
@require_login
def l3_courses():
    # A single fabricated course leads to the session list.
    courses = [{"course_id": "PY101", "name": "Python 程式設計"}]
    return render_template("l3_courses.html", courses=courses)


@app.route("/l3/course/<course_id>/sessions")
@require_login
def l3_sessions(course_id):
    lang = get_lang()
    sessions = [
        {"session_id": s["session_id"], "date": s["date"],
         "topic": data.session_topic(s, lang)}
        for s in data.sessions()
    ]
    return render_template("l3_sessions.html", course_id=course_id, sessions=sessions)


@app.route("/l3/session/<session_id>/attendance")
@require_login
def l3_attendance(session_id):
    lang = get_lang()
    sess = data.session(session_id)
    if not sess:
        abort(404)
    q = request.args.get("q", "").strip()
    # Table is hidden until the selected session date is submitted.
    rows = None
    if q and q == sess["date"]:
        rows = data.attendance_rows(session_id, scope_id(), lang)
    view = {"session_id": sess["session_id"], "date": sess["date"],
            "topic": data.session_topic(sess, lang)}
    # The calendar receives every session date.  Its client-side code makes
    # only these dates clickable, then opens the matching attendance page.
    available_dates = [
        {
            "date": item["date"],
            "url": url_for("l3_attendance", session_id=item["session_id"],
                           q=item["date"]),
        }
        for item in data.sessions()
    ]
    return render_template(
        "l3_attendance.html",
        sess=view,
        rows=rows,
        q=q,
        available_dates=available_dates,
    )


# ---- Level 4: pagination + AJAX rows -------------------------------------

L4_PAGE_SIZE = 8


@app.route("/l4/attendance")
@require_login
def l4_paginated():
    lang = get_lang()
    sess = data.sessions()[0]  # first session as the demo dataset
    all_rows = data.attendance_rows(sess["session_id"], scope_id(), lang)
    page = max(1, request.args.get("page", 1, type=int))
    total_pages = max(1, (len(all_rows) + L4_PAGE_SIZE - 1) // L4_PAGE_SIZE)
    start = (page - 1) * L4_PAGE_SIZE
    page_rows = all_rows[start:start + L4_PAGE_SIZE]
    view = {"session_id": sess["session_id"], "date": sess["date"]}
    return render_template(
        "l4_paginated.html",
        sess=view,
        rows=page_rows,
        page=page,
        total_pages=total_pages,
        total=len(all_rows),
    )


@app.route("/api/l4/rows")
@require_login
def api_l4_rows():
    lang = get_lang()
    sess = data.sessions()[0]
    all_rows = data.attendance_rows(sess["session_id"], scope_id(), lang)
    offset = request.args.get("offset", 0, type=int)
    limit = request.args.get("limit", L4_PAGE_SIZE, type=int)
    chunk = all_rows[offset:offset + limit]
    return {"total": len(all_rows), "offset": offset, "rows": chunk}


# ---- Level 5: JS-rendered table (needs a real browser) -------------------

@app.route("/l5/")
@require_login
def l5_app():
    # Renders an empty shell; the table is built by static/l5.js from JSON.
    return render_template("l5_app.html")


@app.route("/api/l5/data")
@require_login
def api_l5_data():
    lang = get_lang()
    sid = scope_id()
    return {
        "cols": data.ASSESSMENT_KEYS,
        "labels": data.assessment_labels(lang),
        "headers": {
            "student_id": i18n.t("col_id", lang),
            "name": i18n.t("col_name", lang),
            "class_name": i18n.t("col_class", lang),
            "average": i18n.t("col_average", lang),
        },
        "rows": data.gradebook_rows(sid, lang=lang),
    }


# ---- teacher-only bulk export -------------------------------------------

@app.route("/export/<dataset>.<fmt>")
@require_login
def export_dataset(dataset, fmt):
    lang = get_lang()
    if current_user().get("role") != "teacher":
        abort(403, i18n.t("export_only_teacher", lang))
    try:
        if fmt == "csv":
            body = exports.dataset_csv(dataset, lang)
            return Response(body, mimetype="text/csv", headers={
                "Content-Disposition": f"attachment; filename={dataset}.csv"})
        if fmt == "json":
            return Response(exports.dataset_json(dataset, lang), mimetype="application/json")
    except KeyError:
        abort(404, "unknown dataset")
    abort(404, "unknown format")


def _open_browser():
    webbrowser.open("http://127.0.0.1:5000/")


if __name__ == "__main__":
    # Open the browser once, in the main process only (skip the reloader child),
    # and allow opting out with MOCKIRS_OPEN_BROWSER=0.
    if (os.environ.get("WERKZEUG_RUN_MAIN") != "true"
            and os.environ.get("MOCKIRS_OPEN_BROWSER", "1") != "0"):
        threading.Timer(1.0, _open_browser).start()
    app.run(host="127.0.0.1", port=5000, debug=True)
