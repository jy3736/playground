"""MockIRS support package: data generation, exports, and i18n helpers.

The Flask entry point lives in ``app.py`` at the project root; these modules
hold the supporting logic it imports.
"""
