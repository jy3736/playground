"""Deterministic synthetic data for MockIRS.

All data here is FABRICATED (seeded RNG). It resembles the shape of a real
class roster / gradebook but contains no real student information.

Field keys are kept in English on purpose so that the scraping targets
(JSON keys, CSV headers) stay stable regardless of the chosen UI language.
Field *values* (name, class, status, topic labels) are localized to the
requested language so that shown/retrieved data reflects the user's choice.
"""

import random
import re

SEED = 20260621

LANGS = ("zh", "en")
DEFAULT_LANG = "zh"


def norm_lang(lang):
    return lang if lang in LANGS else DEFAULT_LANG


# Formative assessments: each unit is titled by the MMDD date it was taken.
# Dates follow the weekly class schedule (same base as the attendance sessions).
NUM_ASSESSMENTS = 10


def _weekly_dates(n, base_month=3, base_day=3):
    out = []
    for k in range(n):
        day = base_day + k * 7
        month = base_month + (day - 1) // 30
        d = ((day - 1) % 30) + 1
        out.append((month, d))
    return out


# key == title == MMDD (language-neutral); `date` is the full ISO date.
ASSESSMENTS = [
    {"key": "{:02d}{:02d}".format(m, d), "date": "2026-{:02d}-{:02d}".format(m, d)}
    for (m, d) in _weekly_dates(NUM_ASSESSMENTS)
]
ASSESSMENT_KEYS = [a["key"] for a in ASSESSMENTS]

# Each assessment score is normalized to a 0~100 scale.
SCORE_MAX = 100

# Fabricated student names: homophone (諧音) puns on 金庸 / 倪匡 novel characters.
# Each is (zh pun, en romanization). All are play-on-words, not real people.
_NAMES = [
    ("郭晶", "Guo Jing"),        # 郭靖
    ("黃榮", "Huang Rong"),      # 黃蓉
    ("楊果", "Yang Guo"),        # 楊過
    ("張無極", "Zhang Wuji"),    # 張無忌
    ("令湖崇", "Linghu Chong"),  # 令狐沖
    ("喬鋒", "Qiao Feng"),       # 喬峰
    ("段宇", "Duan Yu"),         # 段譽
    ("魏小寶", "Wei Xiaobao"),   # 韋小寶
    ("周柏通", "Zhou Botong"),   # 周伯通
    ("趙閔", "Zhao Min"),        # 趙敏
    ("周芷柔", "Zhou Zhirou"),   # 周芷若
    ("任瑩瑩", "Ren Yingying"),  # 任盈盈
    ("林平志", "Lin Pingzhi"),   # 林平之
    ("胡飛", "Hu Fei"),          # 胡斐
    ("苗仁峰", "Miao Renfeng"),  # 苗人鳳
    ("袁成志", "Yuan Chengzhi"), # 袁承志
    ("陳家樂", "Chen Jiale"),    # 陳家洛
    ("岳步群", "Yue Buqun"),     # 岳不群
    ("慕容富", "Murong Fu"),     # 慕容復
    ("王玉嫣", "Wang Yuyan"),    # 王語嫣
    ("徐竹", "Xu Zhu"),          # 虛竹
    ("段正純", "Duan Zhengchun"),# 段正淳
    ("黃曜", "Huang Yao"),       # 黃藥師
    ("歐陽峰", "Ouyang Feng"),   # 歐陽鋒
    ("慕婉青", "Mu Wanqing"),    # 木婉清
    ("鍾鈴", "Zhong Ling"),      # 鍾靈
    ("程玲素", "Cheng Lingsu"),  # 程靈素
    ("魏思理", "Wei Sili"),      # 衛斯理（倪匡）
    ("白甦", "Bai Su"),          # 白素（倪匡）
    ("袁振俠", "Yuan Zhenxia"),  # 原振俠（倪匡）
    ("洪靈", "Hong Ling"),       # 紅綾（倪匡）
    ("溫寶玉", "Wen Baoyu"),     # 溫寶裕（倪匡）
    ("陳常青", "Chen Changqing"),# 陳長青（倪匡）
    ("高顏", "Gao Yan"),         # 高彥（倪匡）
    ("羅凱", "Luo Kai"),         # 羅開（倪匡）
    ("藍思", "Lan Si"),          # 藍絲（倪匡）
    ("良晨", "Liang Chen"),      # 良辰（倪匡）
    ("美靜", "Mei Jing"),        # 美景（倪匡）
    ("阿珠", "A Zhu"),           # 阿朱
    ("阿姿", "A Zi"),            # 阿紫
]

# Public courses. Students come from one shared pool and may enrol in more
# than one course, so course rosters OVERLAP. `enroll` is the target number of
# students for that course (>= 25).
COURSES = [
    {
        "course_id": "python",
        "department": {"zh": "資訊工程系 (05)", "en": "Dept. of CSIE (05)"},
        "name": {"zh": "Python 程式設計", "en": "Python Programming"},
        "enroll": 30,
    },
    {
        "course_id": "digital",
        "department": {"zh": "電子工程系 (03)", "en": "Dept. of EE (03)"},
        "name": {"zh": "數位系統設計", "en": "Digital System Design"},
        "enroll": 28,
    },
    {
        "course_id": "datastruct",
        "department": {"zh": "資訊管理系 (07)", "en": "Dept. of IM (07)"},
        "name": {"zh": "資料結構", "en": "Data Structures"},
        "enroll": 26,
    },
]

# Class sections (班級). Every student belongs to one section; this is the
# roster's third column. It is independent of which courses they enrol in.
CLASS_SECTIONS = [
    {
        "department": {"zh": "資訊工程系 (05)", "en": "Dept. of CSIE (05)"},
        "name": {"zh": "四技資工一甲", "en": "4yr CSIE, Yr1, Sec A"},
    },
    {
        "department": {"zh": "電子工程系 (03)", "en": "Dept. of EE (03)"},
        "name": {"zh": "四技電子一甲", "en": "4yr EE, Yr1, Sec A"},
    },
    {
        "department": {"zh": "資訊管理系 (07)", "en": "Dept. of IM (07)"},
        "name": {"zh": "四技資管一甲", "en": "4yr IM, Yr1, Sec A"},
    },
]

# Shared student pool (every name is one distinct student).
POOL_SIZE = len(_NAMES)  # 40

QUIZ_OPTIONS = ["A", "B", "C", "D"]
NUM_STUDENTS = 40
NUM_SESSIONS = 12
NUM_QUIZZES = 5
QUESTIONS_PER_QUIZ = 6
ATTENDANCE_STATES = ["present", "absent", "late"]
ATTENDANCE_LABELS = {
    "zh": {"present": "出席", "absent": "缺席", "late": "遲到"},
    "en": {"present": "Present", "absent": "Absent", "late": "Late"},
}

# Auto-login bypass token (documented in README, intentionally weak).
DEMO_TOKEN = "DEMO"

# Instructor accounts. This system is for instructors ONLY — the roster
# students are data subjects, not users (they never log in).
#
# Authentication is by TEMPLATE, not a fixed list: any login of the form
#   account = <last name><digits>   (letters then digits, e.g. yang1234)
# is accepted, and the password is the <digits> part (e.g. 1234).
# The directory below only supplies nicer Chinese surnames / example accounts;
# accounts outside it still work as long as they match the template.
_ACCOUNT_RE = re.compile(r"^([A-Za-z]+)(\d+)$")

_INSTRUCTOR_DEPT = {"zh": "資訊工程系 (05)", "en": "Dept. of CSIE (05)"}
_INSTRUCTOR_CLASS = {"zh": "教師", "en": "Instructor"}

# (last name, 姓, digits) — known surnames for a nicer display name.
_INSTRUCTOR_DIRECTORY = [
    ("yang", "楊", "1234"),
    ("lin", "林", "2468"),
    ("wang", "王", "1357"),
    ("chen", "陳", "8888"),
    ("liu", "劉", "2580"),
    ("huang", "黃", "1470"),
    ("wu", "吳", "3690"),
    ("tsai", "蔡", "1593"),
    ("cheng", "鄭", "7531"),
    ("hsu", "許", "9512"),
]
# Map a known last name to its 姓 for nicer display when synthesizing.
_SURNAME_ZH = {last: zh for (last, zh, _digits) in _INSTRUCTOR_DIRECTORY}


def _instructor_account(last, digits):
    """Build an instructor account dict for a <last name><digits> login."""
    zh = _SURNAME_ZH.get(last.lower(), last.capitalize())
    return {
        "student_id": last + digits,          # <last name><digits>
        "name": {"zh": zh + "老師", "en": "Prof. " + last.capitalize()},
        "email": "{}{}@mock-irs.local".format(last, digits),
        "department": _INSTRUCTOR_DEPT,
        "class_name": _INSTRUCTOR_CLASS,
        "password": digits,                    # <digits>
        "role": "teacher",
    }


# Example/known instructor accounts (any template-matching login also works).
INSTRUCTORS = [_instructor_account(last, digits)
               for (last, _zh, digits) in _INSTRUCTOR_DIRECTORY]


def _build():
    rng = random.Random(SEED)

    # One shared pool of distinct students; each belongs to one class section.
    roster = []
    for i in range(POOL_SIZE):
        sid = "4b430{:03d}".format(i + 1)
        zh, en = _NAMES[i % len(_NAMES)]
        sec = rng.choice(CLASS_SECTIONS)
        roster.append(
            {
                "student_id": sid,
                "name": {"zh": zh, "en": en},
                "email": "{}@office.stust.edu.tw".format(sid),
                "department": sec["department"],
                "class_name": sec["name"],
                "role": "student",
                "courses": [],  # filled below; a student may be in several
            }
        )

    # Enrolment: overlapping rosters. Each student joins >= 1 course (coverage),
    # then each course is topped up with random students to its target size.
    pool_ids = [s["student_id"] for s in roster]
    by_id = {s["student_id"]: s for s in roster}
    enroll = {c["course_id"]: set() for c in COURSES}
    for sid in pool_ids:
        enroll[rng.choice(COURSES)["course_id"]].add(sid)
    for course in COURSES:
        cid = course["course_id"]
        candidates = pool_ids[:]
        rng.shuffle(candidates)
        for sid in candidates:
            if len(enroll[cid]) >= course["enroll"]:
                break
            enroll[cid].add(sid)
    # Record each student's courses in stable COURSES order.
    enroll = {cid: sorted(ids) for cid, ids in enroll.items()}
    for course in COURSES:
        for sid in enroll[course["course_id"]]:
            by_id[sid]["courses"].append(course["course_id"])

    # Gradebook: one row per student, per-assessment score (0~100) + average.
    grades = {}
    for s in roster:
        row = {}
        vals = []
        for a in ASSESSMENTS:
            # 0 = no submission; otherwise a normalized 0~100 score.
            v = 0 if rng.random() < 0.12 else rng.randint(50, SCORE_MAX)
            row[a["key"]] = v
            vals.append(v)
        row["average"] = round(sum(vals) / len(vals), 1)
        grades[s["student_id"]] = row

    # Attendance: NUM_SESSIONS dated weekly sessions; each student a status.
    sessions = []
    for k, (month, d) in enumerate(_weekly_dates(NUM_SESSIONS)):
        sessions.append(
            {
                "session_id": "S{:02d}".format(k + 1),
                "date": "2026-{:02d}-{:02d}".format(month, d),
                "week": k + 1,
            }
        )

    attendance = {}  # session_id -> {student_id -> status}
    for sess in sessions:
        col = {}
        for s in roster:
            r = rng.random()
            col[s["student_id"]] = (
                "present" if r < 0.82 else ("late" if r < 0.92 else "absent")
            )
        attendance[sess["session_id"]] = col

    # Clicker quizzes: per quiz, per question correct answer + per-student pick.
    quizzes = []
    for q in range(NUM_QUIZZES):
        questions = []
        for n in range(QUESTIONS_PER_QUIZ):
            questions.append(
                {
                    "qid": "Q{}".format(n + 1),
                    "answer": rng.choice(QUIZ_OPTIONS),
                }
            )
        responses = {}  # student_id -> list of {qid, choice, correct}
        for s in roster:
            picks = []
            for ques in questions:
                # 70% chance of choosing the correct answer.
                choice = (
                    ques["answer"]
                    if rng.random() < 0.7
                    else rng.choice(QUIZ_OPTIONS)
                )
                picks.append(
                    {
                        "qid": ques["qid"],
                        "choice": choice,
                        "correct": choice == ques["answer"],
                    }
                )
            responses[s["student_id"]] = picks
        quizzes.append(
            {
                "quiz_id": "QZ{}".format(q + 1),
                "num": q + 1,
                "questions": questions,
                "responses": responses,
            }
        )

    return {
        "roster": roster,
        "enroll": enroll,
        "grades": grades,
        "sessions": sessions,
        "attendance": attendance,
        "quizzes": quizzes,
    }


# Built once at import (deterministic).
DB = _build()


# ---- localization helpers -----------------------------------------------

def assessment_labels(lang="zh"):
    """Column titles for the gradebook: MMDD, language-neutral."""
    return {a["key"]: a["key"] for a in ASSESSMENTS}


def assessment_label(key, lang="zh"):
    return key


def attendance_label(status, lang="zh"):
    return ATTENDANCE_LABELS[norm_lang(lang)].get(status, status)


def quiz_title(quiz, lang="zh"):
    if norm_lang(lang) == "en":
        return "Live Quiz {}".format(quiz["num"])
    return "即時測驗 {}".format(quiz["num"])


def session_topic(sess, lang="zh"):
    if norm_lang(lang) == "en":
        return "Week {}".format(sess["week"])
    return "第 {} 週".format(sess["week"])


def _loc(value, lang):
    """value may be a {lang: str} dict or a plain string."""
    if isinstance(value, dict):
        return value.get(norm_lang(lang), value.get(DEFAULT_LANG, ""))
    return value


# ---- Accessors -----------------------------------------------------------

def all_accounts():
    """Login accounts = instructors only (students are not users)."""
    return list(INSTRUCTORS)


def parse_account(student_id):
    """Return (last_name, digits) if the id matches the template, else None."""
    m = _ACCOUNT_RE.match(student_id or "")
    return (m.group(1), m.group(2)) if m else None


def find_account(student_id):
    """Any login matching <last name><digits> is a valid instructor account."""
    parsed = parse_account(student_id)
    if not parsed:
        return None
    return _instructor_account(*parsed)


def account_view(account, lang="zh"):
    """Localized flat view of an account (for templates)."""
    if not account:
        return None
    return {
        "student_id": account["student_id"],
        "name": _loc(account["name"], lang),
        "email": account["email"],
        "department": _loc(account["department"], lang),
        "class_name": _loc(account["class_name"], lang),
        "role": account.get("role", "student"),
    }


def check_password(student_id, password):
    """Valid iff the id matches <last name><digits> and password == <digits>."""
    parsed = parse_account(student_id)
    return parsed is not None and password == parsed[1]


def roster():
    return DB["roster"]


def courses():
    return COURSES


def course_meta(course_id):
    for c in COURSES:
        if c["course_id"] == course_id:
            return c
    return None


def course_list(lang="zh"):
    """Localized course directory for the public index page."""
    return [
        {
            "course_id": c["course_id"],
            "name": _loc(c["name"], lang),
            "department": _loc(c["department"], lang),
            "size": len(DB["enroll"].get(c["course_id"], [])),
        }
        for c in COURSES
    ]


def roster_rows(course_id=None, lang="zh"):
    """Public roster directory: identity only (id, name, class) — no scores.

    Pass a course_id to limit the rows to a single course's enrolled students.
    Rosters overlap: a student may be enrolled in several courses. The third
    column is the student's class section (班級), not the course.
    """
    rows = []
    for s in DB["roster"]:
        if course_id and course_id not in s.get("courses", []):
            continue
        rows.append(
            {
                "student_id": s["student_id"],
                "name": _loc(s["name"], lang),
                "class_name": _loc(s["class_name"], lang),
            }
        )
    return rows


def student(student_id):
    for s in DB["roster"]:
        if s["student_id"] == student_id:
            return s
    return None


def gradebook_rows(student_id=None, course_id=None, lang="zh"):
    """Full roster (student_id=None) or a single student's gradebook rows.

    Pass a course_id to limit the rows to that course's enrolled students.
    Keys stay English; name/course values are localized.
    """
    rows = []
    targets = DB["roster"] if student_id is None else [student(student_id)]
    for s in targets:
        if s is None:
            continue
        if course_id and course_id not in s.get("courses", []):
            continue
        g = DB["grades"][s["student_id"]]
        row = {
            "student_id": s["student_id"],
            "name": _loc(s["name"], lang),
            "class_name": _loc(s["class_name"], lang),
        }
        row.update(g)
        rows.append(row)
    return rows


def sessions():
    return DB["sessions"]


def session(session_id):
    for s in DB["sessions"]:
        if s["session_id"] == session_id:
            return s
    return None


def attendance_rows(session_id, student_id=None, lang="zh"):
    """Attendance for one session: list of {student_id, name, status, status_label}."""
    col = DB["attendance"].get(session_id, {})
    rows = []
    targets = DB["roster"] if student_id is None else [student(student_id)]
    for s in targets:
        if s is None or s["student_id"] not in col:
            continue
        status = col[s["student_id"]]
        rows.append(
            {
                "student_id": s["student_id"],
                "name": _loc(s["name"], lang),
                "status": status,
                "status_label": attendance_label(status, lang),
            }
        )
    return rows


def quizzes():
    return DB["quizzes"]


def quiz(quiz_id):
    for q in DB["quizzes"]:
        if q["quiz_id"] == quiz_id:
            return q
    return None


def quiz_score_rows(quiz_id, student_id=None, course_id=None, lang="zh"):
    """Per-student score for a quiz: {student_id, name, score, total, percent}.

    Pass a course_id to limit the rows to that course's enrolled students.
    `percent` normalizes the raw score to a 0~100 scale so it can be blended
    with the formative average into an overall grade.
    """
    q = quiz(quiz_id)
    if q is None:
        return []
    rows = []
    targets = DB["roster"] if student_id is None else [student(student_id)]
    n = len(q["questions"])
    for s in targets:
        if s is None:
            continue
        if course_id and course_id not in s.get("courses", []):
            continue
        picks = q["responses"].get(s["student_id"], [])
        score = sum(1 for p in picks if p["correct"])
        rows.append(
            {
                "student_id": s["student_id"],
                "name": _loc(s["name"], lang),
                "score": score,
                "total": n,
                "percent": round(100 * score / n, 1) if n else 0,
            }
        )
    return rows
