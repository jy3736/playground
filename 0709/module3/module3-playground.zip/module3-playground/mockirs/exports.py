"""Export builders for MockIRS download endpoints.

CSV and JSON are always available (stdlib only). XLSX is offered only when
openpyxl is importable; otherwise the caller falls back gracefully.

Keys stay English (stable scrape targets); values are localized to `lang`.
"""

import csv
import io
import json

from . import data

try:
    import openpyxl  # noqa: F401

    HAS_XLSX = True
except Exception:  # pragma: no cover - optional dependency
    HAS_XLSX = False


# Public roster directory: identity only (no scores).
ROSTER_COLUMNS = ["student_id", "name", "class_name"]

# Column order for the gradebook export. The assessment columns are MMDD
# titles; the trailing "average" is each student's mean (0~100).
GRADE_COLUMNS = ["student_id", "name", "class_name"] + data.ASSESSMENT_KEYS + ["average"]


def roster_csv(lang="zh", course_id=None):
    rows = data.roster_rows(course_id, lang)
    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=ROSTER_COLUMNS)
    writer.writeheader()
    for r in rows:
        writer.writerow(r)
    return buf.getvalue()


def roster_json(lang="zh", course_id=None):
    return json.dumps(data.roster_rows(course_id, lang), ensure_ascii=False, indent=2)


def roster_xlsx(lang="zh", course_id=None):
    """Return xlsx bytes for the roster directory, or None if no openpyxl."""
    if not HAS_XLSX:
        return None
    from openpyxl import Workbook

    wb = Workbook()
    ws = wb.active
    ws.title = course_id or "roster"
    ws.append(ROSTER_COLUMNS)
    for r in data.roster_rows(course_id, lang):
        ws.append([r.get(k, "") for k in ROSTER_COLUMNS])
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def gradebook_csv(student_id=None, lang="zh"):
    rows = data.gradebook_rows(student_id, lang=lang)
    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=GRADE_COLUMNS)
    writer.writeheader()
    for r in rows:
        writer.writerow({k: r.get(k, "") for k in GRADE_COLUMNS})
    return buf.getvalue()


def gradebook_json(student_id=None, lang="zh"):
    rows = data.gradebook_rows(student_id, lang=lang)
    return json.dumps(rows, ensure_ascii=False, indent=2)


def gradebook_xlsx(student_id=None, lang="zh"):
    """Return xlsx bytes, or None if openpyxl is unavailable."""
    if not HAS_XLSX:
        return None
    from openpyxl import Workbook

    wb = Workbook()
    ws = wb.active
    ws.title = "grades"
    ws.append(GRADE_COLUMNS)
    for r in data.gradebook_rows(student_id, lang=lang):
        ws.append([r.get(k, "") for k in GRADE_COLUMNS])
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


# ---- generic dataset export (teacher) -----------------------------------

def _attendance_matrix(lang="zh"):
    """Wide attendance table: one row per student, one column per session."""
    sessions = data.sessions()
    headers = ["student_id", "name"] + [s["session_id"] for s in sessions]
    rows = []
    for s in data.roster():
        row = {
            "student_id": s["student_id"],
            "name": data._loc(s["name"], lang),
        }
        for sess in sessions:
            col = data.attendance_rows(sess["session_id"], s["student_id"], lang)
            row[sess["session_id"]] = col[0]["status_label"] if col else ""
        rows.append(row)
    return headers, rows


def _average_rows(lang="zh"):
    """Just identity + the average score (0~100), one row per student."""
    return [
        {"student_id": r["student_id"], "name": r["name"], "average": r["average"]}
        for r in data.gradebook_rows(lang=lang)
    ]


def dataset_csv(dataset, lang="zh"):
    if dataset == "grades":
        return gradebook_csv(lang=lang)
    if dataset == "averages":
        rows = _average_rows(lang)
        buf = io.StringIO()
        writer = csv.DictWriter(buf, fieldnames=["student_id", "name", "average"])
        writer.writeheader()
        for r in rows:
            writer.writerow(r)
        return buf.getvalue()
    if dataset == "attendance":
        headers, rows = _attendance_matrix(lang)
        buf = io.StringIO()
        writer = csv.DictWriter(buf, fieldnames=headers)
        writer.writeheader()
        for r in rows:
            writer.writerow(r)
        return buf.getvalue()
    raise KeyError(dataset)


def dataset_json(dataset, lang="zh"):
    if dataset == "grades":
        return gradebook_json(lang=lang)
    if dataset == "averages":
        return json.dumps(_average_rows(lang), ensure_ascii=False, indent=2)
    if dataset == "attendance":
        _, rows = _attendance_matrix(lang)
        return json.dumps(rows, ensure_ascii=False, indent=2)
    raise KeyError(dataset)
