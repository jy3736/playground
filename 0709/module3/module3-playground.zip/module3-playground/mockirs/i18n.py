"""UI string translations for MockIRS (zh / en).

Data values (names, classes, statuses, topic labels) are localized in data.py;
this module covers the surrounding interface chrome and page copy.
"""

DEFAULT_LANG = "zh"
LANGS = ("zh", "en")

STRINGS = {
    # --- chrome ---------------------------------------------------------
    "brand": {"zh": "MockIRS 互動課堂系統", "en": "MockIRS Interactive Classroom"},
    "tagline": {"zh": "AI 代理人抓取練習場", "en": "AI Agent Scraping Playground"},
    "nav_practices": {"zh": "練習關卡", "en": "Practices"},
    "nav_home": {"zh": "首頁", "en": "Home"},
    "login": {"zh": "登入", "en": "Log in"},
    "logout": {"zh": "登出", "en": "Log out"},
    "role_teacher": {"zh": "教師", "en": "Teacher"},
    "role_student": {"zh": "學生", "en": "Student"},
    "theme": {"zh": "主題", "en": "Theme"},
    "theme_dark": {"zh": "深色", "en": "Dark"},
    "theme_light": {"zh": "淺色", "en": "Light"},
    "language": {"zh": "語言", "en": "Language"},
    "footer": {
        "zh": "MockIRS 為教學練習用之模擬系統，所有資料皆為虛構，僅供本機練習使用。",
        "en": "MockIRS is a simulated system for teaching practice. All data is fictional; local use only.",
    },

    # --- practice names / descriptions (shared) -------------------------
    "ex1": {"zh": "練習一", "en": "Exercise 1"},
    "ex2": {"zh": "練習二", "en": "Exercise 2"},
    "ex3": {"zh": "練習三", "en": "Exercise 3"},
    "ex4": {"zh": "練習四", "en": "Exercise 4"},
    "ex5": {"zh": "練習五", "en": "Exercise 5"},
    "ex6": {"zh": "練習六", "en": "Exercise 6"},
    "lvlb_name": {"zh": "公開名冊（按鈕選課）", "en": "Public Roster (Buttons)"},
    "lvlb_desc": {
        "zh": "免登入即可看到名冊（學號、姓名、班級）；以按鈕（而非下拉選單）切換課程。",
        "en": "Roster (id, name, class) is public; switch course with buttons instead of a dropdown.",
    },
    "l1b_goal": {
        "zh": "免登入，按下方課程按鈕切換班級名冊，或下載名冊檔。",
        "en": "No login: click a course button to switch the roster, or download the roster file.",
    },
    "lvl1_name": {"zh": "公開名冊（下拉選單）", "en": "Public Roster (Dropdown)"},
    "lvl2_name": {"zh": "登入牆", "en": "Login Wall"},
    "lvl3_name": {"zh": "深層導覽 + 搜尋", "en": "Nested Nav + Search"},
    "lvl4_name": {"zh": "分頁 / AJAX", "en": "Pagination / AJAX"},
    "lvl5_name": {"zh": "JavaScript 動態渲染", "en": "JavaScript Rendering"},
    "lvl1_desc": {
        "zh": "免登入即可看到名冊（學號、姓名、班級）；成績分數需教師登入。",
        "en": "Roster (id, name, class) is public; grade scores need a teacher login.",
    },
    "lvl2_desc": {
        "zh": "要先用名冊帳號登入（含 CSRF 與 session cookie）才能看到儀表板。",
        "en": "Log in with a roster account (CSRF + session cookie) to reach the dashboard.",
    },
    "lvl3_desc": {
        "zh": "要一層層點進去，並在搜尋框輸入日期才會顯示表格。",
        "en": "Click through nested pages, then type the date into search to reveal the table.",
    },
    "lvl4_desc": {
        "zh": "資料被分頁載入，要逐頁或呼叫 API 才能取得全部列。",
        "en": "Data is paginated; iterate pages or call the API to collect every row.",
    },
    "lvl5_desc": {
        "zh": "原始 HTML 沒有表格，需要真正的瀏覽器渲染（或找出 JSON 端點）。",
        "en": "No table in the raw HTML; needs a real browser to render (or find the JSON endpoint).",
    },

    # --- home -----------------------------------------------------------
    "home_h1": {"zh": "歡迎來到 MockIRS 互動課堂系統", "en": "Welcome to MockIRS"},
    "home_intro": {
        "zh": "這是一個模擬 Zuvio / FlipClass 的練習用假網站。請練習操作 AI 代理人，把各關卡裡的表格資料抓下來，或下載資料檔。",
        "en": "A fake Zuvio/FlipClass-style site for practice. Drive an AI agent to scrape the tables in each exercise or download the data files.",
    },
    "home_levels_h2": {"zh": "六道關卡（由易到難）", "en": "Six exercises (easy to hard)"},
    "home_login_h2": {"zh": "登入方式", "en": "How to log in"},
    "home_roster_login": {"zh": "教師登入：輸入教師帳號與密碼。", "en": "Instructor login: enter your instructor account and password."},
    "home_auto_login": {
        "zh": "自動登入（新手捷徑）：開啟 /auto-login/<教師帳號>?token=DEMO 即可略過表單。",
        "en": "Auto-login (beginner ramp): open /auto-login/<instructor-id>?token=DEMO to skip the form.",
    },
    "home_hint_accounts": {
        "zh": "提示：教師帳號格式為 <姓><數字>（如 yang1234），密碼即為其中的數字（如 1234）。",
        "en": "Hint: instructor account is <lastname><digits> (e.g. yang1234); password is those digits (e.g. 1234).",
    },

    # --- login ----------------------------------------------------------
    "login_h1": {"zh": "登入", "en": "Log in"},
    "form_account": {"zh": "教師帳號", "en": "Instructor account"},
    "form_password": {"zh": "密碼", "en": "Password"},
    "login_hint": {
        "zh": "教師帳號格式為 <姓><數字>（如 yang1234），密碼即為其中的數字（如 1234）。",
        "en": "Instructor account is <lastname><digits> (e.g. yang1234); the password is those digits (e.g. 1234).",
    },
    "err_csrf": {"zh": "CSRF 驗證失敗，請重新整理頁面。", "en": "CSRF check failed; please refresh the page."},
    "err_credentials": {"zh": "帳號或密碼錯誤。", "en": "Wrong account or password."},
    "err_token": {"zh": "需要正確的 token，例如 ?token=DEMO", "en": "A valid token is required, e.g. ?token=DEMO"},
    "err_no_account": {"zh": "查無此帳號", "en": "Account not found"},

    # --- dashboards -----------------------------------------------------
    "teacher_h1": {"zh": "教師儀表板", "en": "Teacher Dashboard"},
    "teacher_intro": {"zh": "您以教師身分登入，可看到全班資料。", "en": "Logged in as a teacher; you can see the whole class."},
    "student_h1": {"zh": "學生首頁", "en": "Student Home"},
    "student_greet": {"zh": "您好", "en": "Hello"},
    "student_only_self": {"zh": "您只能看到自己的資料。", "en": "You can only see your own data."},
    "export_h2": {"zh": "整批匯出（僅教師）", "en": "Bulk export (teacher only)"},
    "export_grades": {"zh": "成績", "en": "Grades"},
    "export_averages": {"zh": "平均", "en": "Averages"},
    "export_attendance": {"zh": "點名", "en": "Attendance"},
    "export_only_teacher": {"zh": "僅教師帳號可使用整批匯出。", "en": "Bulk export is teacher-only."},

    # --- table headers / common -----------------------------------------
    "col_id": {"zh": "學號", "en": "Student ID"},
    "col_name": {"zh": "姓名", "en": "Name"},
    "col_class": {"zh": "班級", "en": "Class"},
    "col_course": {"zh": "課程", "en": "Course"},
    "col_total": {"zh": "總分", "en": "Total"},
    "col_average": {"zh": "平均", "en": "Average"},
    "col_overall": {"zh": "總成績", "en": "Overall"},
    "col_status": {"zh": "狀態", "en": "Status"},
    "col_score": {"zh": "得分", "en": "Score"},
    "col_full": {"zh": "滿分", "en": "Out of"},
    "goal": {"zh": "目標", "en": "Goal"},
    "download": {"zh": "下載", "en": "Download"},
    "download_all": {"zh": "下載全部", "en": "Download all"},
    "students_count": {"zh": "人", "en": "students"},
    "select_course": {"zh": "選擇課程", "en": "Select course"},
    "all_courses": {"zh": "全部課程", "en": "All courses"},
    "overall_quiz": {"zh": "計入測驗", "en": "Include quiz"},
    "quiz_none": {"zh": "不計入", "en": "None"},

    # --- L1 -------------------------------------------------------------
    "l1_goal": {"zh": "免登入，直接抓下方名冊表格，或下載名冊檔。", "en": "No login: scrape the roster table below or download the roster file."},
    "l1_note": {
        "zh": "公開名冊只含學號、姓名、班級；形成性評量分數請以教師身分登入後於練習三查看。",
        "en": "The public roster contains only id, name and class; grade scores require a teacher login (see Exercise 3).",
    },

    # --- L2 -------------------------------------------------------------
    "l2_goal": {"zh": "先登入（含 CSRF 與 session cookie），才能看到這些表格。", "en": "Log in first (CSRF + session cookie) to see these tables."},
    "l2_grades_h2": {"zh": "成績", "en": "Grades"},
    "l2_quiz_h2": {"zh": "即時測驗成績", "en": "Live Quiz Scores"},

    # --- L3 -------------------------------------------------------------
    "l3_courses_h1": {"zh": "課程列表", "en": "Courses"},
    "l3_courses_goal": {
        "zh": "一層層點進去（課程 → 上課場次 → 點名），並在搜尋框輸入該場次日期才會顯示表格。",
        "en": "Click through (course → session → attendance), then type the session date into search to reveal the table.",
    },
    "l3_sessions_h1": {"zh": "上課場次", "en": "Sessions"},
    "l3_sessions_goal": {
        "zh": "點選任一場次進入點名頁，再輸入該場次的日期才會顯示表格。",
        "en": "Pick a session, then enter its date to reveal the attendance table.",
    },
    "l3_att_h1": {"zh": "點名", "en": "Attendance"},
    "l3_att_goal": {"zh": "請在下方搜尋框輸入本場次日期，才會顯示點名表格。", "en": "Type this session's date into the search box to reveal the attendance table."},
    "search_date": {"zh": "搜尋日期", "en": "Search date"},
    "search": {"zh": "搜尋", "en": "Search"},
    "l3_not_shown": {"zh": "尚未顯示資料。提示：請輸入正確的場次日期。", "en": "No data shown yet. Hint: enter the correct session date."},
    "no_data": {"zh": "查無資料。", "en": "No data found."},

    # --- L4 -------------------------------------------------------------
    "l4_h1": {"zh": "分頁點名", "en": "Paginated Attendance"},
    "l4_goal_a": {"zh": "資料共", "en": "Total"},
    "l4_goal_b": {"zh": "列、分成", "en": "rows across"},
    "l4_goal_c": {
        "zh": "頁。請逐頁抓取，或呼叫 AJAX API 取得全部列再彙整。",
        "en": "pages. Scrape page by page, or call the AJAX API to gather every row.",
    },
    "prev_page": {"zh": "上一頁", "en": "Prev"},
    "next_page": {"zh": "下一頁", "en": "Next"},
    "page_word": {"zh": "頁", "en": "page"},
    "page_of": {"zh": "第 {p} / {n} 頁", "en": "Page {p} of {n}"},

    # --- L5 -------------------------------------------------------------
    "l5_h1": {"zh": "JavaScript 動態渲染", "en": "JavaScript Rendering"},
    "l5_goal": {
        "zh": "本頁原始 HTML 內沒有表格資料；表格由 JavaScript 於瀏覽器中向 /api/l5/data 取得 JSON 後動態建立。請用真正的瀏覽器（例如 Playwright）渲染後再抓，或直接呼叫該 JSON 端點。",
        "en": "The raw HTML has no table; JavaScript fetches /api/l5/data and builds it in the browser. Render with a real browser (e.g. Playwright), or call the JSON endpoint directly.",
    },
    "l5_loading": {"zh": "資料載入中…（需要 JavaScript）", "en": "Loading… (JavaScript required)"},
}


def norm_lang(lang):
    return lang if lang in LANGS else DEFAULT_LANG


def t(key, lang=DEFAULT_LANG):
    entry = STRINGS.get(key)
    if not entry:
        return key
    return entry.get(norm_lang(lang), entry.get(DEFAULT_LANG, key))
