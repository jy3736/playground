// A small dependency-free calendar.  Native <input type="date"> controls
// cannot reliably disable individual dates, so this calendar can enforce that
// only sessions with attendance data are selectable.
(() => {
  const trigger = document.querySelector("#date-picker-trigger");
  const calendar = document.querySelector("#session-calendar");
  const hiddenInput = document.querySelector("#selected-date");
  const selectedText = document.querySelector("#selected-date-text");

  if (!trigger || !calendar || !hiddenInput || !selectedText) return;

  const sessions = JSON.parse(calendar.dataset.dates || "[]");
  const sessionByDate = new Map(sessions.map((session) => [session.date, session]));
  let visibleMonth = new Date(`${trigger.dataset.currentDate}T00:00:00`);

  // Build a local YYYY-MM-DD value. toISOString() would shift a Taiwan
  // midnight back to the previous UTC date.
  const formatDate = (date) => [
    date.getFullYear(),
    String(date.getMonth() + 1).padStart(2, "0"),
    String(date.getDate()).padStart(2, "0"),
  ].join("-");
  const monthTitle = new Intl.DateTimeFormat(document.documentElement.lang || "zh-TW", {
    year: "numeric", month: "long",
  });

  function renderCalendar() {
    const year = visibleMonth.getFullYear();
    const month = visibleMonth.getMonth();
    const firstWeekday = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const cells = [];

    for (let index = 0; index < firstWeekday; index += 1) {
      cells.push('<span class="calendar-blank" aria-hidden="true"></span>');
    }

    for (let day = 1; day <= daysInMonth; day += 1) {
      const date = new Date(year, month, day);
      const isoDate = formatDate(date);
      const session = sessionByDate.get(isoDate);
      const isSelected = isoDate === hiddenInput.value;
      if (session) {
        cells.push(`<button class="calendar-day available${isSelected ? " selected" : ""}" type="button" data-date="${isoDate}" aria-label="${isoDate}，有點名資料">${day}</button>`);
      } else {
        cells.push(`<span class="calendar-day" aria-label="${isoDate}，無資料">${day}</span>`);
      }
    }

    calendar.innerHTML = `
      <div class="calendar-header">
        <button class="calendar-nav" type="button" data-action="previous" aria-label="上一個月">‹</button>
        <span class="calendar-month">${monthTitle.format(visibleMonth)}</span>
        <button class="calendar-nav" type="button" data-action="next" aria-label="下一個月">›</button>
      </div>
      <div class="calendar-weekdays" aria-hidden="true"><span>日</span><span>一</span><span>二</span><span>三</span><span>四</span><span>五</span><span>六</span></div>
      <div class="calendar-grid">${cells.join("")}</div>`;
  }

  function toggleCalendar(show) {
    calendar.hidden = !show;
    trigger.setAttribute("aria-expanded", String(show));
    if (show) renderCalendar();
  }

  trigger.addEventListener("click", () => toggleCalendar(calendar.hidden));
  calendar.addEventListener("click", (event) => {
    const button = event.target.closest("button");
    if (!button) return;
    if (button.dataset.action) {
      visibleMonth = new Date(visibleMonth.getFullYear(), visibleMonth.getMonth() + (button.dataset.action === "next" ? 1 : -1), 1);
      renderCalendar();
      return;
    }
    const session = sessionByDate.get(button.dataset.date);
    if (!session) return;
    hiddenInput.value = session.date;
    selectedText.textContent = session.date;
    window.location.assign(session.url);
  });

  document.addEventListener("click", (event) => {
    // Changing months redraws the calendar, which removes the button that was
    // clicked. Use the original event path so that redraw does not look like
    // an outside click and accidentally close the calendar.
    const clickWasInsideCalendar = event.composedPath().includes(calendar);
    if (!calendar.hidden && !clickWasInsideCalendar && !trigger.contains(event.target)) {
      toggleCalendar(false);
    }
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") toggleCalendar(false);
  });
})();
