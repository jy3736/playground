// Level 5: build the gradebook table client-side from JSON.
// This means the table is NOT present in the raw HTML response; an agent must
// render the page in a real browser (or call /api/l5/data directly).
(function () {
  fetch("/api/l5/data", { credentials: "same-origin" })
    .then(function (r) {
      if (!r.ok) throw new Error("HTTP " + r.status);
      return r.json();
    })
    .then(function (data) {
      var app = document.getElementById("grades-app");
      app.innerHTML = "";

      var table = document.createElement("table");
      table.id = "grades";
      table.className = "data";

      var H = data.headers || {};
      var thead = document.createElement("thead");
      var hr = document.createElement("tr");
      [H.student_id || "ID", H.name || "Name", H.class_name || "Class"].forEach(function (h) {
        var th = document.createElement("th");
        th.textContent = h;
        hr.appendChild(th);
      });
      data.cols.forEach(function (t) {
        var th = document.createElement("th");
        th.textContent = data.labels[t] || t;
        hr.appendChild(th);
      });
      var avgTh = document.createElement("th");
      avgTh.textContent = H.average || "Average";
      hr.appendChild(avgTh);
      thead.appendChild(hr);
      table.appendChild(thead);

      var tbody = document.createElement("tbody");
      data.rows.forEach(function (row) {
        var tr = document.createElement("tr");
        var cells = [row.student_id, row.name, row.class_name];
        data.cols.forEach(function (t) {
          cells.push(row[t]);
        });
        cells.push(row.average);
        cells.forEach(function (c) {
          var td = document.createElement("td");
          td.textContent = c;
          tr.appendChild(td);
        });
        tbody.appendChild(tr);
      });
      table.appendChild(tbody);
      app.appendChild(table);
    })
    .catch(function (e) {
      var l = document.getElementById("loading");
      if (l) l.textContent = "Load failed / 載入失敗: " + e.message;
    });
})();
